---
title: "BLiP Weekly 💙"
layout: post
author: ravpacheco
lang: pt
ref: blip-weekly-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "Newsletter sobre a plataforma BLiP"
category: project
---

BLiP Weekly é uma newsletter (email semanal) sobre a [plataforma BLiP](https://blip.ai/) e outros assuntos relacionados ao mundo de chatbots. O objetivo principal é ajudar os usuários da plataforma a se manterem atualizados sobre novas funcionalidades, novos conteúdos, dicas e discussões sobre o produto.

![Imagem de banner sobre o BLiP Weekly](../assets/images/2019-06-01-projeto-blip-weekly/blip-weekly.png){: class="bigger-image"}

[Clique aqui](https://www.getrevue.co/profile/blip) para ver a página principal do BLiP Weekly.