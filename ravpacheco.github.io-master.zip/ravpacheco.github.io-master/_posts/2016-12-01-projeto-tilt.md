---
title: "tilt - <b>T</b>oday <b>I</b> <b>l</b>earned <b>T</b>his ✏️"
layout: page
author: ravpacheco
lang: pt
ref: tilt-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "Lista de alguns pequenos e interessantes aprendizados do dia a dia."
category: project
---

> Today I Learned This (Hoje eu aprendi isto)

Este projeto é inspirado no [TIL](https://github.com/jbranchaud/til) e seu propósito é armazenar e indexar algumas pequenas coisas que eu venho aprendendo.
Eu mudei o nome do projeto apenas para fazer uma piada com a palavra '[tilt](https://pt.wikipedia.org/wiki/Tilt)'.

[Clique aqui](https://github.com/ravpacheco/tilt/) para ver a página principal do projeto tilt.