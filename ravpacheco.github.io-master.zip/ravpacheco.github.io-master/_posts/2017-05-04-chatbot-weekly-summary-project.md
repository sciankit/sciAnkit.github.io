---
title: "Chatbot weekly summary 📅"
layout: post
author: ravpacheco
lang: en
ref: chatbot-weekly-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "Streams list of Caio's weekly sumary commenting about chatbot"
category: project
---

> Chatbot weekly summary

Every week my friend [Caio Calado](https://medium.com/@caio_caladoo) write on [BotsBrasil](medium.com/botsbrasil) medium a summary highlighting some of the most important posts about chatbots around the world. You can found all weekly summaries [here](https://medium.com/@caio_caladoo).

Every tuesday I and Caio make a Facebook Live Stream talking about the current summary. The videos proposal is give to the community our vision and opinion about chatbot subjects. We also reply some community questions during each live.

This page is a directory with all videos.

> *Note: All videos are in portuguese*

### Week #034

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1519034884826725%2F&show_text=1&width=560" width="560" height="451" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #033

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1511263305603883%2F&show_text=1&width=560" width="560" height="451" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #032

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1502698836460330%2F&show_text=1&width=560" width="560" height="451" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #031

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1494806250582922%2F&show_text=1&width=560" width="560" height="445" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #030

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1486770801386467%2F&show_text=1&width=560" width="560" height="451" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #029

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1478997748830439%2F&show_text=1&width=560" width="560" height="445" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #028

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1471049366291944%2F&show_text=1&width=560" width="560" height="470" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #027

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1463530773710470%2F&show_text=1&width=560" width="560" height="470" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #026

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1454612291268985%2F&show_text=1&width=560" width="560" height="489" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #025

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1447482525315295%2F&show_text=1&width=560" width="560" height="444" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #024

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1438334356230112%2F&show_text=1&width=560" width="560" height="469" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #020

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1403245416405673%2F&show_text=1&width=560" width="560" height="508" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

### Week #019

<iframe src="https://www.facebook.com/plugins/video.php?href=https%3A%2F%2Fwww.facebook.com%2FCaioCalado%2Fvideos%2F1393689487361266%2F&show_text=1&width=560" width="560" height="470" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>