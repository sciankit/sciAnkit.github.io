---
title: "check-name 📛"
layout: post
author: ravpacheco
lang: en
ref: check-name-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "Simplest, cheapest and easiest API to check if there is a correct first name in a string"
category: project
---

The propose of this project is enable a simple, cheap and easy API to check if there is a correct first name in a string. If you are creating a bot, probably, you will need validade first names in some moment.

[Click here](https://github.com/ravpacheco/check-name/) to see check-name project home page