**Poema o risco**

Rir é correr risco de parecer tolo. 
Chorar é correr o risco de parecer sentimental. 
Estender a mão é correr o risco de se envolver. 
Expor seus sentimentos é correr o risco
de mostrar seu verdadeiro eu. 
Defender seus sonhos e idéias diante da multidão
é correr o risco de perder as pessoas. 
Amar é correr o risco de não ser correspondido. 
Viver é correr o risco de morrer. 
Confiar é correr o risco de se decepcionar. 
Tentar é correr o risco de fracassar. 
Mas os riscos devem ser corridos, 
porque o maior perigo é não arriscar nada. 
Há pessoas que não correm nenhum risco, 
não fazem nada, não têm nada e não são nada. 
Elas podem até evitar sofrimentos e desilusões,
mas elas não conseguem nada, não sentem nada,
não mudam, não crescem, não amam, não vivem. 
Acorrentadas por suas atitudes, elas viram
escravas, privam-se de sua liberdade. 
Somente a pessoa que corre riscos é livre!

http://www.momento.com.br/pt/ler_texto.php?id=4000&let=C&stat=0