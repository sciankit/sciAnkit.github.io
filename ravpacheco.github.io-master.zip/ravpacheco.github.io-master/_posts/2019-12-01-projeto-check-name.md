---
title: "check-name 📛"
layout: post
author: ravpacheco
lang: pt
ref: check-name-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "A API mais fácil, barata e simples de usar para verificar se existem nomes válidos em uma string"
category: project
---

O objetivo deste projeto é permitir que qualquer pessoa consiga validar se existem nomes próprios em uma string qualquer, de forma simples, fácil e barata. Se você está construindo um bot, provavelmente, precisará validar nomes em algum momento.

[Clique aqui](https://github.com/ravpacheco/check-name/) para ver a página principal do projeto check-name.