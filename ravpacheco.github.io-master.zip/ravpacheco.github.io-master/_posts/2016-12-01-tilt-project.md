---
title: "tilt - <b>T</b>oday <b>I</b> <b>l</b>earned <b>T</b>his ✏️"
layout: post
author: ravpacheco
lang: en
ref: tilt-project
img: indigo/indigo.png
tag: projects
projects: true
summary: "List of some small good things that I have learned some day"
category: project
---

This project is inspired on [TIL](https://github.com/jbranchaud/til) and your propose is store and index some small and good things that I have learned some day.
I changed the project name only to make a joke with the portuguese '[tilt](https://pt.wikipedia.org/wiki/Tilt)' word.

[Click here](https://github.com/ravpacheco/tilt/) to see tilt project home