---
title: "Como criar um chatbot incrível (Apresentação)"
layout: post
date: 2017-11-23 22:48
author: ravpacheco
lang: pt
ref: cb4d-presentation
image: /assets/images/2017-11-23-chatbot4devs-apresentacao/logo.jpg
headerImage: true
tag:
- bots
- chatbot
- chatbot4devs
- presentations
blog: true
description: Apresentação no evento Chatbot4Devs 2017 com algumas estratégias para se construir um chatbot incrível.
externalLink: true
category: blog
---


* **Título:** <span class="evidence">Como criar um chatbot incrível</span>
* **Descrição:** Apresentação no evento Chatbot4Devs 2017 com algumas estratégias para se construir um chatbot incrível..

* **Evento:** [Chatbot4Devs 2017](http://chatbot4devs.take.net/)

    O evento [Chatbot4Devs](http://chatbot4devs.take.net/), organizado todos os anos pela [Take](https://take.net), é considerado por muitos como a maior imersão sobre chatbots, para desenvolvedores(as), do Brasil! 

    Video

    <iframe width="560" height="315" src="https://www.youtube.com/embed/Kty_T3Hce_Q" frameborder="0" gesture="media" allowfullscreen></iframe>